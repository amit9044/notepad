package come.ctrl;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import come.entiy.Todo;

@Controller
public class HomeCtrl {
	@RequestMapping("/home")
	public String home(Model m) {
		String str="home";
		m.addAttribute("page",str);
		return "home";
	}
	@RequestMapping("/add")
	public String add(Model m) {
		Todo t=new Todo();
		m.addAttribute("page","add" );
		m.addAttribute("Todo",t);
		return "home";
	}
}
